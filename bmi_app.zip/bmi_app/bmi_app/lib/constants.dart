import 'package:flutter/material.dart';

const kLabelTextStyle = TextStyle(
  fontSize: 16.0,
  color: Color(0xFF8D8E98),
);

const kActiveColor = Color(0xFF1D1E33);
const kInactiveColor = Color(0xFF111328);
