package com.example.bmi_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
